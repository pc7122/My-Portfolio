import { motion } from "framer-motion";
import { Sparkles, Coffee, MapPin, Calendar } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="relative py-32 px-5 sm:px-8">
      <div className="max-w-7xl mx-auto">
        <SectionHeader eyebrow="About" title="The person behind the pixels" />

        <div className="mt-16 grid lg:grid-cols-12 gap-10">
          {/* Avatar card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-4"
          >
            <div className="sticky top-28">
              <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-br from-white/[0.03] to-transparent p-1">
                <div className="aspect-[4/5] rounded-[1.4rem] bg-gradient-to-br from-yellow-400/30 via-purple-500/20 to-sky-500/20 relative overflow-hidden grid place-items-center">
                  <div className="absolute inset-0 noise" />
                  <div className="text-[10rem] font-display font-bold text-white/10 select-none">
                    PC
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-black via-black/80 to-transparent">
                    <div className="font-display text-xl font-semibold">Prathamesh Chaudhary</div>
                    <div className="text-sm text-yellow-300">React Native · IoT Engineer</div>
                  </div>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <InfoChip Icon={MapPin} label="Pune, India" />
                <InfoChip Icon={Calendar} label="3+ yrs exp" />
                <InfoChip Icon={Coffee} label="Coffee-fueled" />
                <InfoChip Icon={Sparkles} label="Hiring? Yes" />
              </div>
            </div>
          </motion.div>

          {/* Text content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="lg:col-span-8 space-y-6"
          >
            <p className="text-2xl sm:text-3xl font-display leading-snug text-white/90">
              I'm a mobile engineer who fell in love with the moment a phone makes a
              physical machine <span className="text-yellow-400">do something</span>.
            </p>
            <p className="text-gray-400 leading-relaxed">
              For the past three years I've been building production React Native apps
              for <span className="text-white">smart vending machines</span> — handling
              everything from BLE pairing and MDB protocol bridges to cashless payment
              flows, real-time inventory dashboards, and remote firmware updates over MQTT.
            </p>
            <p className="text-gray-400 leading-relaxed">
              I think the best mobile experiences are invisible: a tap, a flash of feedback,
              a coffee in your hand. My goal is to make hardware feel like magic — and to
              ship code that fleet operators can actually rely on at 2 AM.
            </p>

            {/* Highlights */}
            <div className="grid sm:grid-cols-3 gap-4 pt-4">
              {[
                {
                  k: "What I do best",
                  v: "Cross-platform React Native apps with native modules for Bluetooth, NFC, and serial peripherals.",
                },
                {
                  k: "Currently",
                  v: "Leading the mobile stack for a 200-machine vending fleet across India.",
                },
                {
                  k: "Looking for",
                  v: "IoT product teams that care about UX as much as uptime.",
                },
              ].map((h, i) => (
                <motion.div
                  key={h.k}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 * i }}
                  className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-yellow-400/30 transition-colors"
                >
                  <div className="text-xs uppercase tracking-widest text-yellow-400/80 font-mono mb-2">
                    {h.k}
                  </div>
                  <p className="text-sm text-gray-300 leading-relaxed">{h.v}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function InfoChip({ Icon, label }: { Icon: any; label: string }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-sm">
      <Icon size={14} className="text-yellow-400" />
      <span className="text-gray-300">{label}</span>
    </div>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-start">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-400/10 border border-yellow-400/20 text-yellow-300 text-xs font-mono uppercase tracking-widest mb-5"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
        {eyebrow}
      </motion.div>
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight max-w-3xl"
      >
        {title}
      </motion.h2>
      {description && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-gray-400 max-w-2xl"
        >
          {description}
        </motion.p>
      )}
    </div>
  );
}
