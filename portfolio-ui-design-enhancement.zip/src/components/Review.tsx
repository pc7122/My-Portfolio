import { motion } from "framer-motion";
import {
  Layout,
  Palette,
  Compass,
  ImageIcon,
  Gauge,
  CheckCircle2,
} from "lucide-react";
import { SectionHeader } from "./About";

const recommendations = [
  {
    Icon: Layout,
    area: "Layout & Structure",
    rating: "Before: 6/10 → After: 9/10",
    bullets: [
      "Replace flat 4-column grids with bento-style asymmetric layouts to create visual hierarchy.",
      "Add a sticky scroll-spy navbar with active section indicator (implemented above).",
      "Introduce 'eyebrow' labels above headings to reinforce information scent.",
    ],
  },
  {
    Icon: Palette,
    area: "Color & Typography",
    rating: "High Impact · Low Effort",
    bullets: [
      "Pair display font (Space Grotesk) with body (Inter) and mono (JetBrains Mono).",
      "Move from pure black (#000) to a near-black (#0a0a0f) — easier on eyes & enables depth.",
      "Use a triadic accent: yellow + purple + sky for gradients instead of flat yellow.",
    ],
  },
  {
    Icon: Compass,
    area: "Navigation & UX",
    rating: "High Impact",
    bullets: [
      "Pill-style nav with framer-motion `layoutId` for smooth active transitions.",
      "Add a top scroll-progress bar for orientation on long pages.",
      "Mobile: replace hamburger jump with full-screen animated overlay.",
    ],
  },
  {
    Icon: ImageIcon,
    area: "Content Presentation",
    rating: "Critical for portfolio",
    bullets: [
      "Lead with a phone mockup showcasing your actual app domain (vending UI).",
      "Each project card should surface a metric (uptime, throughput, model size).",
      "Group skills by domain (Mobile / IoT / Cloud) instead of percentage bars.",
    ],
  },
  {
    Icon: Gauge,
    area: "Performance & Motion",
    rating: "Tech recommendations",
    bullets: [
      "Smooth scroll: native CSS `scroll-behavior: smooth` + `IntersectionObserver` for reveals.",
      "Use `framer-motion` `whileInView` (already in use) — lighter than AOS/GSAP for SPAs.",
      "Lazy-load below-fold images, prefer SVG/CSS for decoration, keep total JS < 150KB gz.",
    ],
  },
  {
    Icon: CheckCircle2,
    area: "Accessibility",
    rating: "Often missed",
    bullets: [
      "Maintain 4.5:1 contrast ratio — yellow on near-black passes; yellow on yellow does not.",
      "Add `prefers-reduced-motion` media query to disable blob/marquee animations.",
      "Every interactive element needs a focus ring (`focus-visible:ring-2`).",
    ],
  },
];

export default function Review() {
  return (
    <section className="relative py-32 px-5 sm:px-8 bg-gradient-to-b from-transparent via-yellow-400/[0.02] to-transparent">
      <div className="max-w-7xl mx-auto">
        <SectionHeader
          eyebrow="Design Review"
          title="What changed — and why."
          description="A side-by-side breakdown of the original portfolio vs. this redesign, mapped to your six feedback areas."
        />

        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {recommendations.map((r, i) => (
            <motion.div
              key={r.area}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
              className="p-6 rounded-2xl border border-white/10 bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="w-11 h-11 rounded-xl bg-yellow-400/10 border border-yellow-400/20 grid place-items-center text-yellow-400">
                  <r.Icon size={20} />
                </div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-gray-500 text-right max-w-[50%] leading-tight">
                  {r.rating}
                </span>
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold">{r.area}</h3>
              <ul className="mt-3 space-y-2">
                {r.bullets.map((b) => (
                  <li
                    key={b}
                    className="text-sm text-gray-400 flex gap-2 leading-relaxed"
                  >
                    <span className="text-yellow-400 mt-1.5 shrink-0">▸</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Tools recommendation row */}
        <div className="mt-10 p-6 rounded-2xl border border-yellow-400/20 bg-gradient-to-r from-yellow-400/10 via-purple-500/5 to-sky-500/10">
          <div className="flex flex-wrap items-center gap-x-8 gap-y-3 justify-between">
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-yellow-300">
                Recommended Stack
              </div>
              <div className="text-white font-display text-lg mt-1">
                Used to build this exact page →
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                "Vite + React 19",
                "Tailwind CSS v4",
                "Framer Motion",
                "Lucide Icons",
                "IntersectionObserver",
                "CSS Scroll Snap",
              ].map((t) => (
                <span
                  key={t}
                  className="px-3 py-1.5 rounded-full text-xs font-mono bg-black/30 border border-white/10 text-gray-200"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
