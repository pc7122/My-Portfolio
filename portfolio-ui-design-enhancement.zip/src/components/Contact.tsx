import { motion } from "framer-motion";
import { Mail, Phone, MapPin, ArrowUpRight, Send } from "lucide-react";
import { useState } from "react";

const GH = (p: { size?: number }) => (
  <svg width={p.size ?? 16} height={p.size ?? 16} viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56v-2c-3.2.7-3.87-1.37-3.87-1.37-.53-1.34-1.3-1.7-1.3-1.7-1.06-.72.08-.71.08-.71 1.17.08 1.79 1.2 1.79 1.2 1.04 1.78 2.73 1.27 3.4.97.1-.75.41-1.27.74-1.56-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .98-.31 3.2 1.18a11.1 11.1 0 015.83 0c2.21-1.49 3.19-1.18 3.19-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.84 1.19 3.1 0 4.42-2.69 5.39-5.25 5.68.42.36.79 1.07.79 2.16v3.2c0 .31.21.67.8.55C20.21 21.39 23.5 17.08 23.5 12 23.5 5.65 18.35.5 12 .5z"/></svg>
);
const LI = (p: { size?: number }) => (
  <svg width={p.size ?? 16} height={p.size ?? 16} viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.95v5.66H9.36V9h3.4v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.59 0 4.26 2.36 4.26 5.43v6.31zM5.34 7.43a2.06 2.06 0 11-.01-4.13 2.06 2.06 0 01.01 4.13zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.72C24 .77 23.2 0 22.22 0z"/></svg>
);
const X = (p: { size?: number }) => (
  <svg width={p.size ?? 16} height={p.size ?? 16} viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
);

export default function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="relative py-32 px-5 sm:px-8 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-gradient-to-br from-yellow-500/20 via-purple-500/10 to-sky-500/10 blur-[120px]" />

      <div className="relative max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-400/10 border border-yellow-400/20 text-yellow-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
            Let's build something
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight">
            Got a machine that needs <br />
            <span className="text-gradient">a brain?</span>
          </h2>
          <p className="mt-6 text-lg text-gray-400 max-w-2xl mx-auto">
            Whether it's a vending fleet, a coffee robot, or "just" a really good
            mobile app — I'd love to hear about it.
          </p>
        </motion.div>

        <div className="mt-16 grid lg:grid-cols-5 gap-8">
          {/* Form */}
          <motion.form
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
              setTimeout(() => setSent(false), 3500);
            }}
            className="lg:col-span-3 p-8 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Your name" placeholder="Jane Doe" />
              <Field label="Email" type="email" placeholder="jane@company.com" />
            </div>
            <div className="mt-4">
              <Field label="Subject" placeholder="React Native + IoT consulting" />
            </div>
            <div className="mt-4">
              <label className="text-xs font-mono uppercase tracking-widest text-gray-500">
                Message
              </label>
              <textarea
                rows={5}
                placeholder="Tell me about your project, timeline, and any hardware you're working with…"
                className="mt-2 w-full px-4 py-3 rounded-xl bg-black/30 border border-white/10 focus:border-yellow-400/50 focus:outline-none focus:ring-2 focus:ring-yellow-400/20 transition resize-none text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={sent}
              className="mt-5 w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-yellow-400 text-black font-semibold hover:bg-yellow-300 transition-colors disabled:bg-green-400"
            >
              {sent ? "Message sent ✓" : (<>Send message <Send size={16} /></>)}
            </button>
            <p className="mt-3 text-xs text-gray-500 text-center">
              Or just email me directly — I read everything.
            </p>
          </motion.form>

          {/* Contact info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-3"
          >
            <ContactCard Icon={Mail} label="Email" value="prathameshchaudhary7122@gmail.com" href="mailto:prathameshchaudhary7122@gmail.com" />
            <ContactCard Icon={Phone} label="Phone" value="+91 92842 40426" href="tel:+919284240426" />
            <ContactCard Icon={MapPin} label="Location" value="Pune, Maharashtra, India" />

            <div className="p-5 rounded-2xl bg-gradient-to-br from-yellow-400/10 to-transparent border border-yellow-400/20">
              <div className="text-xs font-mono uppercase tracking-widest text-yellow-300">
                Find me elsewhere
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {[
                  { Icon: GH, label: "GitHub" },
                  { Icon: LI, label: "LinkedIn" },
                  { Icon: X, label: "X/Twitter" },
                ].map(({ Icon, label }) => (
                  <a
                    key={label}
                    href="#"
                    className="group flex flex-col items-center gap-1.5 py-3 rounded-xl bg-black/20 border border-white/5 hover:bg-yellow-400/10 hover:border-yellow-400/30 transition-colors"
                  >
                    <Icon size={18} />
                    <span className="text-[10px] text-gray-400 group-hover:text-yellow-300">{label}</span>
                  </a>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Field({ label, ...rest }: any) {
  return (
    <div>
      <label className="text-xs font-mono uppercase tracking-widest text-gray-500">
        {label}
      </label>
      <input
        {...rest}
        className="mt-2 w-full px-4 py-3 rounded-xl bg-black/30 border border-white/10 focus:border-yellow-400/50 focus:outline-none focus:ring-2 focus:ring-yellow-400/20 transition text-sm"
      />
    </div>
  );
}

function ContactCard({
  Icon,
  label,
  value,
  href,
}: {
  Icon: any;
  label: string;
  value: string;
  href?: string;
}) {
  const Cmp: any = href ? "a" : "div";
  return (
    <Cmp
      href={href}
      className="group flex items-center gap-4 p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-yellow-400/30 transition-colors"
    >
      <div className="w-11 h-11 rounded-xl bg-yellow-400/10 border border-yellow-400/20 grid place-items-center text-yellow-400 shrink-0">
        <Icon size={18} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[10px] font-mono uppercase tracking-widest text-gray-500">
          {label}
        </div>
        <div className="text-sm text-white truncate">{value}</div>
      </div>
      {href && (
        <ArrowUpRight
          size={16}
          className="text-gray-500 group-hover:text-yellow-400 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all"
        />
      )}
    </Cmp>
  );
}
