import { motion } from "framer-motion";
import { ArrowRight, Mail, Download, Cpu, Wifi, Battery } from "lucide-react";

const GithubIcon = (props: { size?: number }) => (
  <svg width={props.size ?? 16} height={props.size ?? 16} viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56v-2c-3.2.7-3.87-1.37-3.87-1.37-.53-1.34-1.3-1.7-1.3-1.7-1.06-.72.08-.71.08-.71 1.17.08 1.79 1.2 1.79 1.2 1.04 1.78 2.73 1.27 3.4.97.1-.75.41-1.27.74-1.56-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .98-.31 3.2 1.18a11.1 11.1 0 015.83 0c2.21-1.49 3.19-1.18 3.19-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.84 1.19 3.1 0 4.42-2.69 5.39-5.25 5.68.42.36.79 1.07.79 2.16v3.2c0 .31.21.67.8.55C20.21 21.39 23.5 17.08 23.5 12 23.5 5.65 18.35.5 12 .5z"/></svg>
);
const LinkedinIcon = (props: { size?: number }) => (
  <svg width={props.size ?? 16} height={props.size ?? 16} viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.95v5.66H9.36V9h3.4v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.59 0 4.26 2.36 4.26 5.43v6.31zM5.34 7.43a2.06 2.06 0 11-.01-4.13 2.06 2.06 0 01.01 4.13zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.55C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.72C24 .77 23.2 0 22.22 0z"/></svg>
);

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center pt-28 pb-20 overflow-hidden"
    >
      {/* Background blobs */}
      <div className="absolute inset-0 grid-bg" />
      <div className="absolute -top-32 -left-32 w-[500px] h-[500px] rounded-full bg-yellow-500/20 blur-[120px] animate-blob" />
      <div className="absolute top-40 -right-32 w-[500px] h-[500px] rounded-full bg-purple-500/20 blur-[120px] animate-blob" style={{ animationDelay: "4s" }} />
      <div className="absolute bottom-0 left-1/3 w-[400px] h-[400px] rounded-full bg-sky-500/15 blur-[120px] animate-blob" style={{ animationDelay: "8s" }} />
      <div className="absolute inset-0 noise" />

      <div className="relative max-w-7xl mx-auto px-5 sm:px-8 grid lg:grid-cols-12 gap-12 items-center w-full">
        {/* Left content */}
        <div className="lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-yellow-400/30 bg-yellow-400/5 text-yellow-300 text-sm mb-6"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
            </span>
            Available for freelance & full-time
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold leading-[1.05] tracking-tight"
          >
            Hey, I'm <span className="text-gradient">Prathamesh</span>.
            <br />
            <span className="text-white/90">I build </span>
            <span className="relative inline-block">
              <span className="text-gradient">mobile apps</span>
              <svg
                className="absolute -bottom-2 left-0 w-full"
                viewBox="0 0 300 12"
                fill="none"
              >
                <motion.path
                  d="M2 9 Q 75 2, 150 7 T 298 5"
                  stroke="url(#g1)"
                  strokeWidth="3"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.2, delay: 0.8 }}
                />
                <defs>
                  <linearGradient id="g1" x1="0" x2="1">
                    <stop stopColor="#facc15" />
                    <stop offset="1" stopColor="#a78bfa" />
                  </linearGradient>
                </defs>
              </svg>
            </span>
            <br />
            <span className="text-white/90">that talk to </span>
            <span className="text-gradient">hardware</span>.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-7 text-lg text-gray-400 max-w-xl leading-relaxed"
          >
            React Native developer specializing in{" "}
            <span className="text-white">smart vending machines</span> and IoT-connected
            mobile experiences. I bridge the gap between physical devices and the
            apps that control them.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#projects"
              className="group inline-flex items-center gap-2 px-6 py-3 rounded-full bg-yellow-400 text-black font-medium hover:bg-yellow-300 transition-all hover:gap-3 glow-yellow"
            >
              View my work
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 hover:bg-white/5 hover:border-white/30 transition-colors text-sm"
            >
              <Download size={16} />
              Download Resume
            </a>
            <div className="flex items-center gap-2 ml-2">
              {[
                { Icon: GithubIcon, href: "#" },
                { Icon: LinkedinIcon, href: "#" },
                { Icon: Mail, href: "#contact" },
              ].map(({ Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  className="w-10 h-10 grid place-items-center rounded-full border border-white/10 hover:border-yellow-400 hover:text-yellow-400 transition-colors"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </motion.div>

          {/* Stats strip */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.55 }}
            className="mt-12 grid grid-cols-3 gap-8 max-w-md"
          >
            {[
              { v: "3+", l: "Years building apps" },
              { v: "20+", l: "Vending machines deployed" },
              { v: "15+", l: "Shipped projects" },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-3xl font-bold text-gradient">
                  {s.v}
                </div>
                <div className="text-xs text-gray-500 mt-1 leading-snug">{s.l}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Right phone mockup */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, rotate: -8 }}
          animate={{ opacity: 1, scale: 1, rotate: -6 }}
          transition={{ duration: 1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="lg:col-span-5 relative flex justify-center"
        >
          <div className="relative animate-float">
            {/* Phone */}
            <div className="relative w-[280px] h-[560px] rounded-[3rem] bg-gradient-to-br from-zinc-800 to-zinc-900 p-3 shadow-2xl shadow-yellow-500/10 border border-white/10">
              {/* Notch */}
              <div className="absolute top-3 left-1/2 -translate-x-1/2 w-32 h-7 bg-black rounded-b-2xl z-20" />
              {/* Screen */}
              <div className="phone-screen w-full h-full rounded-[2.3rem] overflow-hidden relative">
                {/* Status bar */}
                <div className="flex items-center justify-between px-6 pt-4 pb-2 text-[10px] text-white/70">
                  <span className="font-mono">9:41</span>
                  <div className="flex items-center gap-1">
                    <Wifi size={11} />
                    <Battery size={14} />
                  </div>
                </div>
                {/* App content - vending machine UI */}
                <div className="p-5 pt-3">
                  <div className="text-[10px] text-yellow-300/80 uppercase tracking-widest">
                    Smart Vendor
                  </div>
                  <div className="text-white font-display text-xl font-semibold mt-0.5">
                    Machine #VM-204
                  </div>

                  <div className="mt-4 p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur">
                    <div className="flex items-center justify-between text-[10px] text-gray-400">
                      <span className="flex items-center gap-1.5">
                        <Cpu size={11} className="text-green-400" />
                        Connected
                      </span>
                      <span>Lobby · Floor 2</span>
                    </div>
                    <div className="mt-2 h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "78%" }}
                        transition={{ delay: 1.2, duration: 1.5 }}
                        className="h-full bg-gradient-to-r from-yellow-400 to-orange-400"
                      />
                    </div>
                    <div className="text-[9px] text-gray-500 mt-1.5">
                      Inventory · 78%
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-2">
                    {[
                      { n: "Coffee", p: "$2.50", c: "from-amber-500/30 to-orange-600/30" },
                      { n: "Water", p: "$1.00", c: "from-sky-500/30 to-blue-600/30" },
                      { n: "Snack", p: "$1.75", c: "from-rose-500/30 to-pink-600/30" },
                      { n: "Soda", p: "$2.00", c: "from-emerald-500/30 to-teal-600/30" },
                    ].map((item, i) => (
                      <motion.div
                        key={item.n}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 1.4 + i * 0.1 }}
                        className={`p-2.5 rounded-xl bg-gradient-to-br ${item.c} border border-white/10`}
                      >
                        <div className="w-8 h-8 rounded-lg bg-white/10 mb-2" />
                        <div className="text-[10px] text-white font-medium">
                          {item.n}
                        </div>
                        <div className="text-[10px] text-gray-300">{item.p}</div>
                      </motion.div>
                    ))}
                  </div>

                  <motion.button
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 2 }}
                    className="mt-4 w-full py-2.5 rounded-xl bg-yellow-400 text-black text-xs font-semibold"
                  >
                    Tap to Pay · $2.50
                  </motion.button>
                </div>
              </div>
            </div>

            {/* Floating cards */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.2 }}
              className="absolute -left-12 top-20 px-3 py-2 rounded-xl bg-white/10 backdrop-blur-xl border border-white/20 shadow-xl"
            >
              <div className="flex items-center gap-2 text-xs">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-white/90">BLE paired</span>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.4 }}
              className="absolute -right-10 bottom-32 px-3 py-2 rounded-xl bg-yellow-400 text-black shadow-xl"
            >
              <div className="text-[10px] font-semibold">+ $128.40 today</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.6 }}
              className="absolute -right-6 top-10 w-12 h-12 rounded-full bg-purple-500/30 backdrop-blur-xl border border-purple-300/30 grid place-items-center"
            >
              <Wifi size={18} className="text-purple-200" />
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Marquee */}
      <div className="absolute bottom-0 left-0 right-0 py-5 border-y border-white/5 bg-black/30 backdrop-blur overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex items-center gap-12 px-6 text-sm text-gray-500 font-mono">
              {[
                "React Native",
                "TypeScript",
                "BLE / IoT",
                "MQTT",
                "Firebase",
                "Redux Toolkit",
                "Expo",
                "Node.js",
                "Stripe",
                "Reanimated",
                "GraphQL",
                "Native Modules",
              ].map((t) => (
                <span key={t} className="flex items-center gap-12">
                  {t}
                  <span className="text-yellow-400">◆</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
