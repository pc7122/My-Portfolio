import { Heart } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-10 px-5 sm:px-8">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500">
        <div>
          © {new Date().getFullYear()} Prathamesh Chaudhary. Crafted with{" "}
          <Heart size={12} className="inline text-red-400 fill-red-400" /> in Pune.
        </div>
        <div className="flex items-center gap-6 text-xs">
          <a href="#home" className="hover:text-yellow-400">Back to top ↑</a>
          <span className="font-mono text-gray-600">v3.0 — 2026</span>
        </div>
      </div>
    </footer>
  );
}
