import { motion } from "framer-motion";
import { ArrowUpRight, Cpu, Wifi, Smartphone, ShoppingCart, Camera, Brain } from "lucide-react";
import { SectionHeader } from "./About";

const projects = [
  {
    tag: "Flagship",
    Icon: ShoppingCart,
    title: "VendOS — Smart Vending Platform",
    blurb:
      "End-to-end React Native app + cloud control plane for a 200+ machine vending fleet. BLE pairing, MDB protocol, UPI/card payments, and live inventory analytics.",
    stack: ["React Native", "TypeScript", "BLE", "MQTT", "Node.js", "PostgreSQL"],
    color: "from-yellow-500 to-orange-500",
    metric: { v: "₹4.2L", l: "monthly throughput" },
    accent: "bg-yellow-400",
  },
  {
    tag: "Hardware",
    Icon: Cpu,
    title: "FleetSync — Remote OTA Dashboard",
    blurb:
      "Real-time telemetry and over-the-air firmware updates for embedded coffee machines. Push to one machine or 500 — gracefully.",
    stack: ["React Native", "MQTT", "AWS IoT Core", "ESP32", "Lambda"],
    color: "from-purple-500 to-pink-500",
    metric: { v: "99.7%", l: "uptime" },
    accent: "bg-purple-400",
  },
  {
    tag: "Mobile",
    Icon: Smartphone,
    title: "TapPay — Cashless Kiosk SDK",
    blurb:
      "Drop-in React Native SDK that turns any kiosk Android into a UPI/NFC payment terminal in under 4 lines of code.",
    stack: ["React Native", "Native Modules", "Kotlin", "Razorpay", "NFC"],
    color: "from-sky-500 to-blue-500",
    metric: { v: "<2s", l: "tap-to-confirm" },
    accent: "bg-sky-400",
  },
  {
    tag: "AI / Vision",
    Icon: Camera,
    title: "EmoSense — Multimodal Emotion AI",
    blurb:
      "FastAPI + React app that detects emotion from face and audio in real time. Fine-tuned CNN + spectrogram pipeline.",
    stack: ["Python", "TensorFlow", "FastAPI", "React", "OpenCV"],
    color: "from-emerald-500 to-teal-500",
    metric: { v: "94%", l: "F1 score" },
    accent: "bg-emerald-400",
  },
  {
    tag: "IoT",
    Icon: Wifi,
    title: "Mesh — Indoor BLE Beacon Network",
    blurb:
      "Self-healing BLE mesh that lets vending machines talk to each other without WiFi. Built for low-connectivity venues.",
    stack: ["React Native", "BLE Mesh", "ESP32", "C++"],
    color: "from-rose-500 to-red-500",
    metric: { v: "30+", l: "node hop range" },
    accent: "bg-rose-400",
  },
  {
    tag: "ML",
    Icon: Brain,
    title: "PlantHealth — On-device Diagnosis",
    blurb:
      "TFLite model running locally on Android to diagnose 38 plant diseases from a single photo. No internet required.",
    stack: ["TensorFlow Lite", "React Native", "Python"],
    color: "from-amber-500 to-yellow-500",
    metric: { v: "12MB", l: "model size" },
    accent: "bg-amber-400",
  },
];

export default function Projects() {
  return (
    <section id="projects" className="relative py-32 px-5 sm:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
          <SectionHeader
            eyebrow="Selected Work"
            title="Things I've shipped that beep, vend, or just look pretty."
          />
          <a
            href="#"
            className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-yellow-400 transition-colors group whitespace-nowrap"
          >
            See all on GitHub
            <ArrowUpRight size={16} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </div>

        <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map((p, i) => (
            <motion.article
              key={p.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
              className="group relative rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-white/[0.01] overflow-hidden hover:border-white/25 transition-all duration-500"
            >
              {/* Gradient header */}
              <div className={`relative h-44 bg-gradient-to-br ${p.color} overflow-hidden`}>
                <div className="absolute inset-0 noise" />
                <div
                  className="absolute inset-0 opacity-30"
                  style={{
                    backgroundImage:
                      "radial-gradient(circle at 80% 20%, rgba(255,255,255,0.4), transparent 50%)",
                  }}
                />
                <div className="absolute top-4 left-4 px-2.5 py-1 rounded-full bg-black/30 backdrop-blur text-[10px] font-mono uppercase tracking-widest text-white">
                  {p.tag}
                </div>
                <div className="absolute bottom-4 right-4">
                  <div className="text-right">
                    <div className="font-display text-3xl font-bold text-white drop-shadow">
                      {p.metric.v}
                    </div>
                    <div className="text-[10px] uppercase tracking-widest text-white/80">
                      {p.metric.l}
                    </div>
                  </div>
                </div>
                <p.Icon
                  size={64}
                  className="absolute -bottom-3 -left-3 text-black/20 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-700"
                  strokeWidth={1.5}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#16161f] to-transparent" />
              </div>

              {/* Body */}
              <div className="p-6">
                <h3 className="font-display text-xl font-semibold leading-snug group-hover:text-yellow-400 transition-colors">
                  {p.title}
                </h3>
                <p className="mt-2 text-sm text-gray-400 leading-relaxed line-clamp-3">
                  {p.blurb}
                </p>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {p.stack.map((s) => (
                    <span
                      key={s}
                      className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-gray-400"
                    >
                      {s}
                    </span>
                  ))}
                </div>
                <div className="mt-5 flex items-center gap-3">
                  <a
                    href="#"
                    className="text-sm text-white inline-flex items-center gap-1 hover:gap-2 transition-all"
                  >
                    Case study
                    <ArrowUpRight size={14} />
                  </a>
                  <span className="text-gray-600">·</span>
                  <a href="#" className="text-sm text-gray-500 hover:text-white">
                    Live demo
                  </a>
                </div>
              </div>

              {/* Hover bottom border */}
              <div className={`absolute bottom-0 left-0 h-[3px] ${p.accent} w-0 group-hover:w-full transition-all duration-500`} />
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
