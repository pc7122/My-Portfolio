import { motion } from "framer-motion";
import { Briefcase, GraduationCap } from "lucide-react";
import { SectionHeader } from "./About";

const experience = [
  {
    role: "Senior React Native Engineer",
    org: "VendCo Smart Retail",
    when: "2024 — Present",
    points: [
      "Lead mobile engineer for a 200-machine smart vending fleet across 12 cities.",
      "Designed BLE pairing flow that cut onboarding time from 8 minutes to 45 seconds.",
      "Shipped UPI + card SDK now powering ₹4.2L/mo in transactions.",
    ],
  },
  {
    role: "Mobile Developer — IoT",
    org: "Ahen Pvt. Ltd.",
    when: "2023 — 2024",
    points: [
      "Built React Native control app for connected coffee machines using MQTT over TLS.",
      "Implemented OTA firmware update pipeline with rollback safety.",
      "Reduced cold-boot time of the operator app by 62%.",
    ],
  },
  {
    role: "Data / App Engineer Intern",
    org: "NoQs Digital",
    when: "2023",
    points: [
      "Owned dashboarding and automation reducing manual processing by 40%.",
      "Prototyped first iteration of mobile-first inventory tooling.",
    ],
  },
];

const education = [
  {
    degree: "B.E. — Artificial Intelligence",
    org: "AISSMS Institute of Information Technology",
    when: "2021 — 2024",
  },
  {
    degree: "Diploma — Computer Engineering",
    org: "Government Polytechnic",
    when: "2018 — 2021",
  },
];

export default function Experience() {
  return (
    <section id="experience" className="relative py-32 px-5 sm:px-8 bg-gradient-to-b from-transparent via-white/[0.015] to-transparent">
      <div className="max-w-7xl mx-auto">
        <SectionHeader
          eyebrow="Journey"
          title="From terminal to deployed fleet."
        />

        <div className="mt-16 grid lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
            <SubHeader Icon={Briefcase} title="Experience" />
            <div className="relative mt-8 pl-8 border-l border-white/10 space-y-12">
              {experience.map((e, i) => (
                <motion.div
                  key={e.role}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="relative"
                >
                  {/* Dot */}
                  <div className="absolute -left-[2.4rem] top-1.5 w-4 h-4 rounded-full bg-yellow-400 ring-4 ring-yellow-400/20" />
                  <div className="text-xs font-mono text-yellow-400 uppercase tracking-widest">
                    {e.when}
                  </div>
                  <h4 className="mt-2 font-display text-xl font-semibold">{e.role}</h4>
                  <div className="text-gray-400 text-sm">{e.org}</div>
                  <ul className="mt-3 space-y-1.5">
                    {e.points.map((p) => (
                      <li
                        key={p}
                        className="text-sm text-gray-400 flex gap-2 leading-relaxed"
                      >
                        <span className="text-yellow-400 mt-1.5">▸</span>
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </div>

          <div>
            <SubHeader Icon={GraduationCap} title="Education" />
            <div className="mt-8 space-y-4">
              {education.map((e, i) => (
                <motion.div
                  key={e.degree}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-5 rounded-2xl border border-white/10 bg-white/[0.02] hover:border-yellow-400/30 transition-colors"
                >
                  <div className="text-xs font-mono text-yellow-400 uppercase tracking-widest">
                    {e.when}
                  </div>
                  <div className="mt-2 font-display text-lg font-semibold leading-snug">
                    {e.degree}
                  </div>
                  <div className="text-sm text-gray-400 mt-1">{e.org}</div>
                </motion.div>
              ))}

              <div className="mt-6 p-5 rounded-2xl bg-gradient-to-br from-yellow-400/10 to-transparent border border-yellow-400/20">
                <div className="text-xs font-mono uppercase tracking-widest text-yellow-300 mb-2">
                  Certifications
                </div>
                <ul className="text-sm text-gray-300 space-y-1.5">
                  <li>• Machine Learning Specialization — DeepLearning.AI</li>
                  <li>• Apps with SQL & Django — IBM Skill Network</li>
                  <li>• Java Fundamentals — Oracle Academy</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SubHeader({ Icon, title }: { Icon: any; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-9 h-9 rounded-lg bg-yellow-400/10 border border-yellow-400/20 grid place-items-center text-yellow-400">
        <Icon size={18} />
      </div>
      <h3 className="font-display text-2xl font-semibold">{title}</h3>
    </div>
  );
}
