import { motion } from "framer-motion";
import {
  Smartphone,
  Wifi,
  Code2,
  Cloud,
  Wrench,
  Zap,
} from "lucide-react";
import { SectionHeader } from "./About";

const groups = [
  {
    Icon: Smartphone,
    title: "Mobile",
    color: "from-yellow-400 to-orange-500",
    items: ["React Native", "Expo", "TypeScript", "Reanimated", "Native Modules", "Swift / Kotlin basics"],
  },
  {
    Icon: Wifi,
    title: "IoT & Hardware",
    color: "from-purple-400 to-pink-500",
    items: ["BLE (react-native-ble-plx)", "MDB protocol", "MQTT", "NFC", "ESP32 / Raspberry Pi", "Serial peripherals"],
  },
  {
    Icon: Code2,
    title: "Frontend Web",
    color: "from-sky-400 to-blue-500",
    items: ["React 19", "Next.js", "Tailwind CSS", "Framer Motion", "Zustand", "TanStack Query"],
  },
  {
    Icon: Cloud,
    title: "Backend & Cloud",
    color: "from-emerald-400 to-teal-500",
    items: ["Node.js", "FastAPI", "Firebase", "PostgreSQL", "AWS IoT Core", "Docker"],
  },
  {
    Icon: Wrench,
    title: "Tools",
    color: "from-rose-400 to-red-500",
    items: ["Git / GitHub Actions", "Fastlane", "Figma", "Sentry", "Postman", "Xcode / Android Studio"],
  },
  {
    Icon: Zap,
    title: "AI & Data",
    color: "from-amber-400 to-yellow-500",
    items: ["TensorFlow", "OpenCV", "Python", "Pandas", "On-device ML", "Edge inference"],
  },
];

export default function Skills() {
  return (
    <section id="skills" className="relative py-32 px-5 sm:px-8">
      <div className="absolute inset-0 grid-bg opacity-50" />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          eyebrow="Skills"
          title="A toolbox built for shipping connected products."
          description="Three years deep in mobile + IoT means I know which tradeoffs save you weeks — and which ones cost you the contract."
        />

        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {groups.map((g, i) => (
            <motion.div
              key={g.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              whileHover={{ y: -4 }}
              className="group relative p-6 rounded-2xl bg-gradient-to-br from-white/[0.04] to-white/[0.01] border border-white/10 hover:border-white/25 transition-colors overflow-hidden"
            >
              <div
                className={`absolute -top-12 -right-12 w-40 h-40 rounded-full bg-gradient-to-br ${g.color} opacity-0 group-hover:opacity-20 blur-2xl transition-opacity duration-500`}
              />
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${g.color} grid place-items-center text-black mb-5 shadow-lg`}
              >
                <g.Icon size={22} strokeWidth={2.2} />
              </div>
              <h3 className="font-display text-xl font-semibold mb-3">{g.title}</h3>
              <ul className="space-y-1.5">
                {g.items.map((it) => (
                  <li
                    key={it}
                    className="text-sm text-gray-400 flex items-center gap-2"
                  >
                    <span className="w-1 h-1 rounded-full bg-yellow-400/60" />
                    {it}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Tech stack badge cloud */}
        <div className="mt-12 p-6 rounded-2xl border border-white/10 bg-white/[0.02]">
          <div className="text-xs font-mono uppercase tracking-widest text-gray-500 mb-4">
            Currently leveling up
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              "Skia for React Native",
              "Matter protocol",
              "TanStack Start",
              "Bun",
              "WatermelonDB",
              "Edge TPU",
              "WebRTC",
              "Rust → mobile FFI",
            ].map((t) => (
              <span
                key={t}
                className="px-3 py-1.5 rounded-full text-xs bg-white/5 border border-white/10 text-gray-300 hover:bg-yellow-400/10 hover:border-yellow-400/30 hover:text-yellow-300 transition-colors cursor-default"
              >
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
