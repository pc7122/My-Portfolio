import { Reveal } from "./Reveal";
import { Briefcase, GraduationCap } from "lucide-react";

const experience = [
  {
    role: "Data Analyst — Intern",
    org: "NoQs Digital",
    period: "Jul 2023 — Sep 2023",
    points: [
      "Built Google Sheets dashboards demonstrating hands-on analytics proficiency.",
      "Spearheaded data analysis & automation initiatives, cutting manual processing 40%.",
      "Applied analytical acumen to surface actionable insights and trends.",
    ],
  },
  {
    role: "Data Science — Intern",
    org: "Ahen Pvt. Ltd.",
    period: "Jan 2023 — Feb 2023",
    points: [
      "Implemented advanced web scraping pipelines to collect & analyze Google Maps data.",
      "Derived insights driving optimization of marketing campaigns and customer satisfaction.",
    ],
  },
  {
    role: "PHP Developer — Trainee",
    org: "R. B. Tech Services",
    period: "Jul 2020 — Aug 2020",
    points: [
      "Designed and shipped a notice management system using PHP, SQL & JavaScript.",
      "Built database-backed responsive UI showcasing adaptability across the stack.",
    ],
  },
];

const education = [
  {
    degree: "Bachelor's Degree (Artificial Intelligence)",
    org: "AISSMS Institute of Information Technology",
    period: "2021 — 2024",
  },
  {
    degree: "Diploma (Computer Engineering)",
    org: "Government Polytechnic",
    period: "2018 — 2021",
  },
  { degree: "SSC", org: "B. N. Sarda Vidyalaya", period: "2017 — 2018" },
];

export const Experience = () => {
  return (
    <section id="experience" className="py-24 lg:py-32 relative">
      <div className="container-wide">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Experience */}
          <div>
            <Reveal>
              <div className="flex items-center gap-3 mb-10">
                <div className="w-10 h-10 rounded-xl bg-gradient-primary grid place-items-center text-primary-foreground shadow-glow">
                  <Briefcase size={18} />
                </div>
                <h2 className="text-3xl font-display font-bold">Experience</h2>
              </div>
            </Reveal>

            <div className="relative pl-8 border-l border-border space-y-10">
              {experience.map((e, i) => (
                <Reveal key={e.role} delay={i * 80}>
                  <div className="relative">
                    <div className="absolute -left-[37px] top-1 w-3.5 h-3.5 rounded-full bg-primary ring-4 ring-background shadow-glow" />
                    <div className="glass rounded-2xl p-6 hover:border-primary/40 transition-colors">
                      <div className="flex flex-wrap justify-between gap-2 mb-1">
                        <h3 className="font-display font-bold text-lg">{e.role}</h3>
                        <span className="font-mono text-xs text-primary">{e.period}</span>
                      </div>
                      <div className="text-sm text-accent mb-4">{e.org}</div>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        {e.points.map((p) => (
                          <li key={p} className="flex gap-2">
                            <span className="text-primary mt-1.5 w-1 h-1 rounded-full bg-primary shrink-0" />
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          {/* Education */}
          <div>
            <Reveal>
              <div className="flex items-center gap-3 mb-10">
                <div className="w-10 h-10 rounded-xl bg-gradient-primary grid place-items-center text-primary-foreground shadow-glow">
                  <GraduationCap size={18} />
                </div>
                <h2 className="text-3xl font-display font-bold">Education</h2>
              </div>
            </Reveal>

            <div className="relative pl-8 border-l border-border space-y-10">
              {education.map((e, i) => (
                <Reveal key={e.degree} delay={i * 80}>
                  <div className="relative">
                    <div className="absolute -left-[37px] top-1 w-3.5 h-3.5 rounded-full bg-accent ring-4 ring-background" />
                    <div className="glass rounded-2xl p-6 hover:border-accent/40 transition-colors">
                      <div className="flex flex-wrap justify-between gap-2 mb-1">
                        <h3 className="font-display font-bold text-lg">{e.degree}</h3>
                        <span className="font-mono text-xs text-accent">{e.period}</span>
                      </div>
                      <div className="text-sm text-primary">{e.org}</div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
