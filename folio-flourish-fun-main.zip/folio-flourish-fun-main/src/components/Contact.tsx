import { Reveal } from "./Reveal";
import { ArrowUpRight, Github, Instagram, Linkedin, Mail } from "lucide-react";

export const Contact = () => {
  return (
    <section id="contact" className="py-24 lg:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-aurora opacity-60 pointer-events-none" />
      <div className="container-wide relative">
        <Reveal>
          <div className="glass-strong rounded-[2rem] lg:rounded-[3rem] p-10 lg:p-20 text-center relative overflow-hidden">
            <div className="absolute -top-20 -left-20 w-72 h-72 bg-primary/30 rounded-full blur-3xl animate-pulse-glow" />
            <div className="absolute -bottom-20 -right-20 w-72 h-72 bg-accent/30 rounded-full blur-3xl animate-pulse-glow" />

            <div className="relative">
              <p className="text-sm font-mono text-primary tracking-widest uppercase mb-6">Let's build together</p>
              <h2 className="text-4xl sm:text-6xl lg:text-7xl font-display font-extrabold tracking-tight leading-[0.95] mb-6">
                Have a product
                <br />
                <span className="text-gradient-primary">that needs shipping?</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-10">
                I'm currently taking on freelance and full-time opportunities in mobile, IoT and applied ML. Let's talk.
              </p>

              <a
                href="mailto:prathameshchaudhary7122@gmail.com"
                className="group inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-primary text-primary-foreground font-medium shadow-glow hover:-translate-y-0.5 transition-all"
              >
                prathameshchaudhary7122@gmail.com
                <ArrowUpRight size={20} className="group-hover:rotate-45 transition-transform" />
              </a>

              <div className="flex justify-center gap-3 mt-10">
                {[
                  { icon: Github, href: "https://github.com" },
                  { icon: Linkedin, href: "https://linkedin.com" },
                  { icon: Instagram, href: "https://instagram.com" },
                  { icon: Mail, href: "mailto:prathameshchaudhary7122@gmail.com" },
                ].map(({ icon: Icon, href }, i) => (
                  <a
                    key={i}
                    href={href}
                    target="_blank"
                    rel="noreferrer"
                    className="w-12 h-12 rounded-xl glass grid place-items-center hover:bg-primary hover:text-primary-foreground transition-all hover:-translate-y-1"
                  >
                    <Icon size={18} />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        <footer className="mt-16 flex flex-wrap justify-between items-center gap-4 text-sm text-muted-foreground">
          <div className="font-mono">© 2026 Prathamesh Chaudhary. Crafted in Pune.</div>
          <div className="font-mono">Built with React + Tailwind</div>
        </footer>
      </div>
    </section>
  );
};
