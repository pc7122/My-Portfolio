import { Reveal } from "./Reveal";

const photos = [
  { src: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=1200&q=80", alt: "Mountain landscape", span: "md:col-span-2 md:row-span-2" },
  { src: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&q=80", alt: "Forest" },
  { src: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&q=80", alt: "Mountain vista" },
  { src: "https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=800&q=80", alt: "Valley" },
  { src: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80", alt: "Misty hills" },
  { src: "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?w=1200&q=80", alt: "Ocean wave", span: "md:col-span-2" },
  { src: "https://images.unsplash.com/photo-1458668383970-8ddd3927deed?w=800&q=80", alt: "Mountain road" },
];

export const Photography = () => {
  return (
    <section id="photography" className="py-24 lg:py-32 relative">
      <div className="container-wide">
        <Reveal className="flex items-end justify-between flex-wrap gap-6 mb-12">
          <div>
            <p className="text-sm font-mono text-primary tracking-widest uppercase mb-4">Off-screen</p>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold tracking-tight">
              Through the <span className="text-gradient-primary">viewfinder.</span>
            </h2>
          </div>
          <p className="text-muted-foreground max-w-md">
            When I'm not shipping code, I'm chasing light across the Sahyadris with my camera.
          </p>
        </Reveal>

        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] gap-3">
          {photos.map((p, i) => (
            <Reveal key={i} delay={i * 50} className={p.span}>
              <div className="group relative w-full h-full rounded-2xl overflow-hidden glass">
                <img
                  src={p.src}
                  alt={p.alt}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
