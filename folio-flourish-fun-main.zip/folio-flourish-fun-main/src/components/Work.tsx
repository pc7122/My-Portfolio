import { Reveal } from "./Reveal";
import { ArrowUpRight } from "lucide-react";
import emosense from "@/assets/project-emosense.jpg";
import plant from "@/assets/project-plant.jpg";
import yolo from "@/assets/project-yolo.jpg";
import vending from "@/assets/project-vending.jpg";
import mobile from "@/assets/project-mobile.jpg";
import iot from "@/assets/project-iot.jpg";

type Project = {
  title: string;
  tag: string;
  image: string;
  stack: string[];
  desc: string;
  span: string;
  accent?: boolean;
};

const projects: Project[] = [
  {
    title: "Smart Vending OS",
    tag: "IoT × Mobile",
    image: vending,
    stack: ["React Native", "Raspberry Pi", "MQTT", "FastAPI"],
    desc: "End-to-end platform for connected vending machines — operator app, real-time inventory telemetry, contactless payments and remote diagnostics.",
    span: "lg:col-span-2 lg:row-span-2",
    accent: true,
  },
  {
    title: "EmoSense",
    tag: "Computer Vision",
    image: emosense,
    stack: ["TensorFlow", "OpenCV"],
    desc: "Multimodal emotion recognition combining facial micro-expressions with audio prosody.",
    span: "lg:col-span-2",
  },
  {
    title: "Operator Mobile App",
    tag: "React Native",
    image: mobile,
    stack: ["React Native", "Expo", "TypeScript"],
    desc: "Cross-platform app for technicians to monitor fleets of vending machines on the go.",
    span: "lg:col-span-2",
  },
  {
    title: "IoT Telemetry Pipeline",
    tag: "Embedded",
    image: iot,
    stack: ["MQTT", "Python", "PostgreSQL"],
    desc: "High-throughput ingestion pipeline streaming sensor data from edge devices to the cloud.",
    span: "lg:col-span-2",
  },
  {
    title: "Plant Disease Detection",
    tag: "AI · FastAPI",
    image: plant,
    stack: ["FastAPI", "TensorFlow", "React"],
    desc: "CNN classifier diagnosing leaf disease from a single photo, served via FastAPI.",
    span: "lg:col-span-2",
  },
  {
    title: "YOLOv5 Car Detection",
    tag: "Computer Vision",
    image: yolo,
    stack: ["PyTorch", "YOLOv5"],
    desc: "Real-time vehicle detection pipeline tuned for low-light traffic footage.",
    span: "lg:col-span-2",
  },
];

export const Work = () => {
  return (
    <section id="work" className="py-24 lg:py-32 relative">
      <div className="container-wide">
        <Reveal className="flex items-end justify-between flex-wrap gap-6 mb-16">
          <div className="max-w-2xl">
            <p className="text-sm font-mono text-primary tracking-widest uppercase mb-4">Selected work</p>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold tracking-tight">
              Things I've shipped <span className="text-gradient-primary">recently.</span>
            </h2>
          </div>
          <a
            href="#mobile"
            className="inline-flex items-center gap-2 text-sm font-mono text-muted-foreground hover:text-primary transition-colors"
          >
            See mobile & IoT focus <ArrowUpRight size={16} />
          </a>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-6 auto-rows-[280px] gap-5">
          {projects.map((p, i) => (
            <Reveal key={p.title} delay={i * 60} className={p.span}>
              <article
                className={`group relative h-full rounded-3xl overflow-hidden glass cursor-pointer transition-all duration-500 hover:shadow-elegant ${
                  p.accent ? "ring-1 ring-primary/30" : ""
                }`}
              >
                <img
                  src={p.image}
                  alt={p.title}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/20" />

                <div className="relative h-full flex flex-col justify-end p-6 lg:p-8">
                  <div className="flex items-start justify-between mb-3">
                    <span className="px-3 py-1 rounded-full glass-strong text-[10px] font-mono uppercase tracking-widest text-primary">
                      {p.tag}
                    </span>
                    <div className="w-10 h-10 rounded-full glass-strong grid place-items-center opacity-0 group-hover:opacity-100 group-hover:rotate-45 transition-all duration-300">
                      <ArrowUpRight size={16} />
                    </div>
                  </div>
                  <h3 className="text-2xl lg:text-3xl font-display font-bold mb-2 tracking-tight">
                    {p.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-2 group-hover:line-clamp-none transition-all">
                    {p.desc}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {p.stack.map((t) => (
                      <span key={t} className="px-2.5 py-1 rounded-md bg-secondary/70 text-[10px] font-mono text-muted-foreground">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
